# Digital Delay 6 (DD-6) — Android Studio Project

Real-time low-latency stereo digital delay stompbox for Android built with **C++20**, **Google Oboe (AAudio / OpenSL ES)**, **JNI**, and **Jetpack Compose (Material 3)**.

## Controls & Modes
- **4 Rotary Knobs:** `E.LEVEL` (Effect Mix), `F.BACK` (Feedback), `D.TIME` (Delay Time), `MODE` (7-Position Selector).
- **7 DD-6 Modes:** `80ms`, `300ms`, `800ms`, `2600ms`, `WARP`, `HOLD (5.2s)`, and `REVERSE`.
- **Footswitch:** Tap to toggle Effect ON/OFF; Press & Hold (>2 sec) to enter Tap Tempo mode (or activate Warp / Hold loop recording depending on mode).
- **Audio Studio:** Live microphone DSP, real-time WAV recording & playback, WAV file import, and processed stereo WAV export.
