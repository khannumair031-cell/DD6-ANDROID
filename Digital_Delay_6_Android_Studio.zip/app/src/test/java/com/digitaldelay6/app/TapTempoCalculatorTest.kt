package com.digitaldelay6.app

import com.digitaldelay6.app.audio.TapTempoCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class TapTempoCalculatorTest {

    @Test
    fun `calculates accurate 120 BPM and 500ms delay`() {
        val calc = TapTempoCalculator()
        assertNull(calc.recordTap(1000L))

        val res = calc.recordTap(1500L)
        assertNotNull(res)
        assertEquals(500f, res!!.delayMs, 0.1f)
        assertEquals(120f, res.bpm, 0.1f)
    }

    @Test
    fun `resets window after timeout gap`() {
        val calc = TapTempoCalculator(maxTapGapMs = 2000L)
        calc.recordTap(1000L)
        calc.recordTap(1500L)

        val afterReset = calc.recordTap(4000L)
        assertNull(afterReset)

        val secondTap = calc.recordTap(4400L)
        assertNotNull(secondTap)
        assertEquals(400f, secondTap!!.delayMs, 0.1f)
        assertEquals(150f, secondTap.bpm, 0.1f)
    }
}
