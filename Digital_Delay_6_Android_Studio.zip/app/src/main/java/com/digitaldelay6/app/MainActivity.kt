package com.digitaldelay6.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.digitaldelay6.app.ui.screen.DelayPedalScreen
import com.digitaldelay6.app.ui.theme.DigitalDelay6Theme
import com.digitaldelay6.app.viewmodel.DelayViewModel

class MainActivity : ComponentActivity() {

    private val delayViewModel: DelayViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val micPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { granted ->
                delayViewModel.setMicPermissionGranted(granted)
                if (granted) {
                    delayViewModel.toggleMicInput(true)
                }
            }

            val importAudioLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    delayViewModel.importAudioUri(this@MainActivity, uri)
                }
            }

            val exportAudioLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.CreateDocument("audio/wav")
            ) { uri ->
                if (uri != null) {
                    delayViewModel.exportProcessedWavUri(this@MainActivity, uri)
                }
            }

            LaunchedEffect(Unit) {
                val hasMic = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                delayViewModel.setMicPermissionGranted(hasMic)
            }

            DigitalDelay6Theme {
                DelayPedalScreen(
                    viewModel = delayViewModel,
                    onRequestMicPermission = {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onImportAudioClick = {
                        importAudioLauncher.launch(arrayOf("audio/wav", "audio/x-wav", "audio/*"))
                    },
                    onExportAudioClick = {
                        exportAudioLauncher.launch("Digital_Delay_6_Processed.wav")
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
