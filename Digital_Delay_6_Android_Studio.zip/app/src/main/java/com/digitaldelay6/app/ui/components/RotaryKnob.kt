package com.digitaldelay6.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun RotaryKnob(
    label: String,
    value: Float,
    defaultValue: Float,
    valueText: String,
    accentColor: Color = Color(0xFF0EA5E9),
    steps: Int = 0,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    knobSize: Dp = 64.dp
) {
    var currentVal by remember(value) { mutableFloatStateOf(value.coerceIn(0f, 1f)) }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.7.sp,
            color = Color(0xFFF8FAFC)
        )

        Spacer(modifier = Modifier.height(5.dp))

        Canvas(
            modifier = Modifier
                .size(knobSize)
                .pointerInput(defaultValue) {
                    detectTapGestures(
                        onDoubleTap = {
                            currentVal = defaultValue.coerceIn(0f, 1f)
                            onValueChange(currentVal)
                        },
                        onTap = {
                            if (steps > 1) {
                                val currentIdx = (currentVal * (steps - 1)).roundToInt()
                                val nextIdx = (currentIdx + 1) % steps
                                currentVal = nextIdx.toFloat() / (steps - 1).toFloat()
                                onValueChange(currentVal)
                            }
                        }
                    )
                }
                .pointerInput(steps) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val delta = (-dragAmount.y + dragAmount.x * 0.5f) / 220f
                        currentVal = (currentVal + delta).coerceIn(0f, 1f)
                        val emitted = if (steps > 1) {
                            val idx = (currentVal * (steps - 1)).roundToInt()
                            idx.toFloat() / (steps - 1).toFloat()
                        } else {
                            currentVal
                        }
                        onValueChange(emitted)
                    }
                }
        ) {
            val strokeWidth = 3.5.dp.toPx()
            val arcPadding = strokeWidth
            val arcDiameter = size.minDimension - arcPadding * 2f
            val topLeft = Offset(arcPadding, arcPadding)
            val arcSize = Size(arcDiameter, arcDiameter)

            val startAngle = 135f
            val maxSweep = 270f

            drawArc(
                color = Color(0xFF283244),
                startAngle = startAngle,
                sweepAngle = maxSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            drawArc(
                color = accentColor,
                startAngle = startAngle,
                sweepAngle = maxSweep * currentVal,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            val center = Offset(size.width / 2f, size.height / 2f)
            val skirtRadius = arcDiameter * 0.41f
            val capRadius = arcDiameter * 0.33f

            drawCircle(
                color = Color(0xFF090C11),
                radius = skirtRadius,
                center = center
            )

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF38BDF8), Color(0xFF0284C7), Color(0xFF0369A1)),
                    center = Offset(center.x - capRadius * 0.25f, center.y - capRadius * 0.25f),
                    radius = capRadius * 1.45f
                ),
                radius = capRadius,
                center = center
            )

            val angleRad = Math.toRadians((startAngle + maxSweep * currentVal).toDouble())
            val innerPt = Offset(
                x = center.x + (capRadius * 0.22f * cos(angleRad)).toFloat(),
                y = center.y + (capRadius * 0.22f * sin(angleRad)).toFloat()
            )
            val outerPt = Offset(
                x = center.x + (skirtRadius * 0.92f * cos(angleRad)).toFloat(),
                y = center.y + (skirtRadius * 0.92f * sin(angleRad)).toFloat()
            )

            drawLine(
                color = Color.White,
                start = innerPt,
                end = outerPt,
                strokeWidth = 2.6.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        Spacer(modifier = Modifier.height(3.dp))

        Text(
            text = valueText,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF7DD3FC)
        )
    }
}
