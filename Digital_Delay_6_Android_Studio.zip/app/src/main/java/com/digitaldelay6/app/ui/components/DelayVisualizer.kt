package com.digitaldelay6.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.digitaldelay6.app.model.Dd6Mode
import com.digitaldelay6.app.model.DelayUiState
import kotlin.math.pow

@Composable
fun DelayVisualizer(
    state: DelayUiState,
    modifier: Modifier = Modifier
) {
    val accent = state.mode.accentColor
    val latencyMs = (state.burstFrames * 2f / state.sampleRateHz.coerceAtLeast(8000)) * 1000f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF070A10))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(14.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = state.mode.title.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = accent
                )
                Text(
                    text = if (state.mode == Dd6Mode.HOLD_52S) {
                        "LOOP: ${"%.2f".format(state.holdDurationSec)}s / 5.20s  •  ${state.holdLoopState.badgeText}"
                    } else {
                        "${state.delayTimeMs.toInt()} ms  •  ${"%.1f".format(state.bpm)} BPM"
                    },
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${state.sampleRateHz / 1000}kHz • ${"%.1f".format(latencyMs)}ms buf",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFF94A3B8)
                )
                Text(
                    text = "PEAK ${(state.outputPeak * 100).toInt()}%",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (state.outputPeak > 0.92f) Color(0xFFEF4444) else Color(0xFF38BDF8)
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(82.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val midY = h * 0.5f

                for (i in 1..4) {
                    val x = w * (i / 5f)
                    drawLine(
                        color = Color(0xFF141C2B),
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 1.dp.toPx()
                    )
                }
                drawLine(
                    color = Color(0xFF1E293B),
                    start = Offset(0f, midY),
                    end = Offset(w, midY),
                    strokeWidth = 1.dp.toPx()
                )

                if (state.mode == Dd6Mode.HOLD_52S) {
                    val barW = w * state.holdProgress.coerceIn(0f, 1f)
                    drawRect(
                        color = accent.copy(alpha = 0.25f),
                        topLeft = Offset.Zero,
                        size = Size(barW, h)
                    )
                } else {
                    val timelineMs = 2650f
                    val stepMs = state.delayTimeMs.coerceAtLeast(10f)
                    val effectiveFb = if (state.mode == Dd6Mode.WARP && state.isPedalHeld) 0.95f else state.feedback
                    var tapIndex = 1
                    var tapTime = stepMs

                    while (tapTime < timelineMs && tapIndex <= 28) {
                        val amp = effectiveFb.pow(tapIndex)
                        if (amp < 0.02f) break
                        val x = (tapTime / timelineMs) * w
                        val barHeight = amp * (h * 0.78f)
                        drawRect(
                            color = accent.copy(alpha = (0.18f + amp * 0.35f).coerceIn(0.05f, 0.55f)),
                            topLeft = Offset(x - 2.dp.toPx(), h - barHeight),
                            size = Size(4.dp.toPx(), barHeight)
                        )
                        tapIndex++
                        tapTime += stepMs
                    }
                }

                val samples = state.waveform
                if (samples.size > 1) {
                    val path = Path()
                    val stepX = w / (samples.size - 1).toFloat()
                    samples.forEachIndexed { idx, sample ->
                        val clamped = sample.coerceIn(-1f, 1f)
                        val x = idx * stepX
                        val y = midY - clamped * (midY * 0.88f)
                        if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = if (state.isBypassed) Color(0xFF475569) else accent,
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        }
    }
}
