package com.digitaldelay6.app.viewmodel

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.digitaldelay6.app.audio.NativeDelayEngine
import com.digitaldelay6.app.audio.TapTempoCalculator
import com.digitaldelay6.app.audio.WavAudioCodec
import com.digitaldelay6.app.model.Dd6Mode
import com.digitaldelay6.app.model.DelayUiState
import com.digitaldelay6.app.model.HoldLoopState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DelayViewModel : ViewModel() {

    private val engine = NativeDelayEngine()
    private val tapTempoCalculator = TapTempoCalculator()

    private val _uiState = MutableStateFlow(DelayUiState())
    val uiState: StateFlow<DelayUiState> = _uiState.asStateFlow()

    private var meteringJob: Job? = null
    private var lastRecordedStereoPcm: FloatArray = FloatArray(0)
    private var importedSourceStereoPcm: FloatArray? = null

    init {
        syncAllParametersToEngine(_uiState.value)
        startEngine()
    }

    fun startEngine() {
        val started = engine.start()
        _uiState.update {
            it.copy(
                isEngineRunning = started,
                statusBanner = if (started) "DD-6 Audio Engine Active" else "Audio Engine Standby"
            )
        }
        if (started) startMeteringLoop()
    }

    fun stopEngine() {
        meteringJob?.cancel()
        engine.stop()
        _uiState.update { it.copy(isEngineRunning = false, statusBanner = "Audio Engine Stopped") }
    }

    private fun startMeteringLoop() {
        meteringJob?.cancel()
        meteringJob = viewModelScope.launch {
            while (isActive) {
                val metrics = engine.pollMetrics()
                val wave = engine.pollWaveform()
                _uiState.update { state ->
                    state.copy(
                        inputRms = metrics.inputRms,
                        outputRms = metrics.outputRms,
                        outputPeak = metrics.outputPeak,
                        sampleRateHz = metrics.sampleRateHz,
                        burstFrames = metrics.burstFrames,
                        holdProgress = metrics.holdProgress,
                        holdDurationSec = metrics.holdDurationSec,
                        importedProgress = metrics.importedProgress,
                        waveform = if (wave.isNotEmpty()) wave else state.waveform
                    )
                }
                delay(16L)
            }
        }
    }

    fun setEffectLevel(level: Float) {
        val clamped = level.coerceIn(0f, 1f)
        engine.setEffectLevel(clamped)
        _uiState.update { it.copy(effectLevel = clamped) }
    }

    fun setFeedback(feedback: Float) {
        val clamped = feedback.coerceIn(0f, 0.96f)
        engine.setFeedback(clamped)
        _uiState.update { it.copy(feedback = clamped) }
    }

    fun setDelayTimeMs(timeMs: Float) {
        val mode = _uiState.value.mode
        val clamped = timeMs.coerceIn(mode.minDelayMs, mode.maxDelayMs)
        engine.setDelayTimeMs(clamped)
        _uiState.update {
            it.copy(
                delayTimeMs = clamped,
                bpm = 60_000f / clamped
            )
        }
    }

    fun setMode(newMode: Dd6Mode) {
        val newTime = newMode.defaultDelayMs.coerceIn(newMode.minDelayMs, newMode.maxDelayMs)
        engine.setMode(newMode)
        engine.setDelayTimeMs(newTime)
        if (newMode != Dd6Mode.HOLD_52S) {
            engine.setHoldState(HoldLoopState.IDLE)
        }
        _uiState.update {
            it.copy(
                mode = newMode,
                delayTimeMs = newTime,
                bpm = 60_000f / newTime,
                isTempoModeActive = false,
                holdLoopState = if (newMode == Dd6Mode.HOLD_52S) it.holdLoopState else HoldLoopState.IDLE,
                statusBanner = "Mode: ${newMode.title}"
            )
        }
    }

    fun onFootswitchPressDown() {
        engine.setPedalHeld(true)
        _uiState.update { it.copy(isPedalHeld = true) }
    }

    fun onFootswitchRelease() {
        engine.setPedalHeld(false)
        _uiState.update { it.copy(isPedalHeld = false) }
    }

    fun onFootswitchTap() {
        val state = _uiState.value
        if (state.mode == Dd6Mode.HOLD_52S) {
            val nextHold = when (state.holdLoopState) {
                HoldLoopState.IDLE -> HoldLoopState.RECORDING
                HoldLoopState.RECORDING -> HoldLoopState.PLAYING
                HoldLoopState.PLAYING -> HoldLoopState.OVERDUBBING
                HoldLoopState.OVERDUBBING -> HoldLoopState.PLAYING
            }
            engine.setHoldState(nextHold)
            engine.setBypass(false)
            _uiState.update {
                it.copy(
                    isBypassed = false,
                    holdLoopState = nextHold,
                    statusBanner = "HOLD (5.2s): ${nextHold.badgeText}"
                )
            }
            return
        }

        if (state.isTempoModeActive) {
            val result = tapTempoCalculator.recordTap(
                nowMs = SystemClock.elapsedRealtime(),
                minMs = state.mode.minDelayMs,
                maxMs = state.mode.maxDelayMs
            ) ?: return
            engine.setDelayTimeMs(result.delayMs)
            _uiState.update {
                it.copy(
                    delayTimeMs = result.delayMs,
                    bpm = result.bpm,
                    statusBanner = "Tap Tempo: ${result.delayMs.toInt()} ms (${"%.1f".format(result.bpm)} BPM)"
                )
            }
            return
        }

        val nextBypassed = !state.isBypassed
        engine.setBypass(nextBypassed)
        _uiState.update {
            it.copy(
                isBypassed = nextBypassed,
                statusBanner = if (nextBypassed) "Effect Bypassed (CHECK LED OFF)" else "Effect Active (CHECK LED ON)"
            )
        }
    }

    fun onFootswitchHoldTwoSeconds() {
        val state = _uiState.value
        if (state.mode == Dd6Mode.HOLD_52S) {
            engine.clearHoldLoop()
            engine.setHoldState(HoldLoopState.IDLE)
            _uiState.update {
                it.copy(
                    holdLoopState = HoldLoopState.IDLE,
                    holdProgress = 0f,
                    holdDurationSec = 0f,
                    statusBanner = "HOLD (5.2s) Loop Cleared"
                )
            }
            return
        }

        if (state.mode == Dd6Mode.WARP) {
            _uiState.update {
                it.copy(statusBanner = "WARP Swell Engaged - Release pedal to decay")
            }
            return
        }

        val nextTempoMode = !state.isTempoModeActive
        tapTempoCalculator.reset()
        _uiState.update {
            it.copy(
                isTempoModeActive = nextTempoMode,
                isBypassed = false,
                statusBanner = if (nextTempoMode) {
                    "TEMPO MODE ACTIVE - Tap pedal to set delay time"
                } else {
                    "Exited Tempo Mode"
                }
            )
        }
        engine.setBypass(false)
    }

    fun setMicPermissionGranted(granted: Boolean) {
        _uiState.update { it.copy(hasMicPermission = granted) }
        if (granted && _uiState.value.isMicInputEnabled) {
            engine.setInputEnabled(true)
        }
    }

    fun toggleMicInput(enabled: Boolean) {
        engine.setInputEnabled(enabled)
        _uiState.update {
            it.copy(
                isMicInputEnabled = enabled,
                statusBanner = if (enabled) "Live Microphone Input Active" else "Live Microphone Muted"
            )
        }
    }

    fun triggerPluck(frequencyHz: Float) {
        if (!_uiState.value.isEngineRunning) startEngine()
        engine.triggerTestPluck(frequencyHz)
    }

    fun toggleOutputRecording() {
        val currentlyRecording = _uiState.value.isRecordingOutput
        if (!currentlyRecording) {
            if (!_uiState.value.isEngineRunning) startEngine()
            engine.setRecording(true)
            _uiState.update {
                it.copy(
                    isRecordingOutput = true,
                    statusBanner = "Recording Processed Stereo Audio..."
                )
            }
        } else {
            engine.setRecording(false)
            val pcm = engine.getRecordedPcm()
            lastRecordedStereoPcm = pcm
            val sr = _uiState.value.sampleRateHz.coerceAtLeast(8000)
            val durationSec = (pcm.size / 2).toFloat() / sr.toFloat()
            _uiState.update {
                it.copy(
                    isRecordingOutput = false,
                    hasRecordedTake = pcm.isNotEmpty(),
                    recordedTakeDurationSec = durationSec,
                    statusBanner = if (pcm.isNotEmpty()) {
                        "Recorded ${"%.1f".format(durationSec)}s Stereo Take"
                    } else {
                        "Recording Stopped (Empty)"
                    }
                )
            }
        }
    }

    fun playRecordedTake() {
        if (lastRecordedStereoPcm.isEmpty()) return
        if (!_uiState.value.isEngineRunning) startEngine()
        engine.loadImportedAudio(lastRecordedStereoPcm)
        engine.setImportedPlayback(playing = true, looping = false)
        _uiState.update {
            it.copy(
                isImportedPlaying = true,
                importedFileName = "Recorded Take (${"%.1f".format(it.recordedTakeDurationSec)}s)",
                statusBanner = "Playing Recorded Take"
            )
        }
    }

    fun importAudioUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(statusBanner = "Importing WAV Audio...") }
            val sr = _uiState.value.sampleRateHz.coerceAtLeast(8000)
            val decoded = withContext(Dispatchers.IO) {
                WavAudioCodec.decodeWavFromUri(context, uri, sr)
            }
            if (decoded == null) {
                _uiState.update {
                    it.copy(statusBanner = "Import Failed - Select a valid PCM WAV file")
                }
                return@launch
            }
            importedSourceStereoPcm = decoded.interleavedStereo
            engine.loadImportedAudio(decoded.interleavedStereo)
            engine.setImportedPlayback(playing = true, looping = true)
            val displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "Imported Audio.wav"
            _uiState.update {
                it.copy(
                    importedFileName = displayName,
                    isImportedPlaying = true,
                    statusBanner = "Imported $displayName (${"%.1f".format(decoded.durationSec)}s)"
                )
            }
        }
    }

    fun toggleImportedPlayback() {
        val next = !_uiState.value.isImportedPlaying
        if (next && !_uiState.value.isEngineRunning) startEngine()
        engine.setImportedPlayback(playing = next, looping = true)
        _uiState.update {
            it.copy(
                isImportedPlaying = next,
                statusBanner = if (next) "Playing Imported Audio through DD-6" else "Playback Paused"
            )
        }
    }

    fun exportProcessedWavUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(statusBanner = "Rendering Processed DD-6 WAV...") }
            val sr = _uiState.value.sampleRateHz.coerceAtLeast(8000)

            val pcmToExport: FloatArray = withContext(Dispatchers.Default) {
                when {
                    lastRecordedStereoPcm.isNotEmpty() -> lastRecordedStereoPcm
                    importedSourceStereoPcm != null -> engine.renderProcessedOffline(importedSourceStereoPcm!!)
                    else -> FloatArray(0)
                }
            }

            if (pcmToExport.isEmpty()) {
                _uiState.update {
                    it.copy(statusBanner = "Nothing to export - Record audio or Import a WAV first")
                }
                return@launch
            }

            val ok = withContext(Dispatchers.IO) {
                WavAudioCodec.writeWavToUri(context, uri, pcmToExport, sr)
            }
            val sec = (pcmToExport.size / 2).toFloat() / sr.toFloat()
            _uiState.update {
                it.copy(
                    statusBanner = if (ok) {
                        "Exported Processed WAV (${"%.1f".format(sec)}s)"
                    } else {
                        "WAV Export Failed"
                    }
                )
            }
        }
    }

    private fun syncAllParametersToEngine(state: DelayUiState) {
        engine.setEffectLevel(state.effectLevel)
        engine.setFeedback(state.feedback)
        engine.setDelayTimeMs(state.delayTimeMs)
        engine.setMode(state.mode)
        engine.setBypass(state.isBypassed)
        engine.setHoldState(state.holdLoopState)
    }

    override fun onCleared() {
        meteringJob?.cancel()
        engine.destroy()
        super.onCleared()
    }
}
