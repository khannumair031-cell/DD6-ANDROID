package com.digitaldelay6.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PedalCream = Color(0xFFE7E0CE)
val PedalCreamDark = Color(0xFFD2C8B2)
val FaceplateBlack = Color(0xFF11151D)
val ChassisDark = Color(0xFF0A0D13)
val BossBlue = Color(0xFF0EA5E9)
val BossBlueDeep = Color(0xFF0284C7)
val CheckLedRed = Color(0xFFEF4444)

private val DigitalDelayDarkScheme = darkColorScheme(
    primary = BossBlue,
    onPrimary = Color.White,
    secondary = PedalCream,
    onSecondary = FaceplateBlack,
    background = ChassisDark,
    onBackground = Color(0xFFF8FAFC),
    surface = FaceplateBlack,
    onSurface = Color(0xFFF8FAFC)
)

@Composable
fun DigitalDelay6Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DigitalDelayDarkScheme,
        content = content
    )
}
