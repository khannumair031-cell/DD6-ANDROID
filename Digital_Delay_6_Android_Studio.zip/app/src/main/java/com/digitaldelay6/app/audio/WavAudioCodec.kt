package com.digitaldelay6.app.audio

import android.content.Context
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class DecodedWavAudio(
    val interleavedStereo: FloatArray,
    val sampleRate: Int,
    val durationSec: Float
)

object WavAudioCodec {

    fun decodeWavFromUri(context: Context, uri: Uri, targetSampleRate: Int = 48000): DecodedWavAudio? {
        val rawBytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (rawBytes.size < 44) return null

        val buf = ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN)
        if (buf.int != 0x46464952) return null
        buf.int
        if (buf.int != 0x45564157) return null

        var audioFormat = 1
        var numChannels = 1
        var sampleRate = targetSampleRate
        var bitsPerSample = 16
        var dataOffset = -1
        var dataSize = 0

        while (buf.remaining() >= 8) {
            val chunkId = buf.int
            val chunkSize = buf.int
            if (chunkSize < 0 || chunkSize > buf.remaining()) break

            if (chunkId == 0x20746d66) {
                audioFormat = buf.short.toInt() and 0xFFFF
                numChannels = buf.short.toInt() and 0xFFFF
                sampleRate = buf.int
                buf.int
                buf.short
                bitsPerSample = buf.short.toInt() and 0xFFFF
                val extra = chunkSize - 16
                if (extra > 0) buf.position(buf.position() + extra)
            } else if (chunkId == 0x61746164) {
                dataOffset = buf.position()
                dataSize = chunkSize
                break
            } else {
                buf.position(buf.position() + chunkSize)
            }
        }

        if (dataOffset < 0 || dataSize <= 0 || numChannels <= 0) return null

        val bytesPerSample = (bitsPerSample / 8).coerceAtLeast(1)
        val totalFrames = dataSize / (bytesPerSample * numChannels)
        if (totalFrames <= 0) return null

        val srcStereo = FloatArray(totalFrames * 2)
        buf.position(dataOffset)

        for (frame in 0 until totalFrames) {
            var left = 0f
            var right = 0f
            for (ch in 0 until numChannels) {
                val sample = when {
                    audioFormat == 3 && bitsPerSample == 32 -> buf.float.coerceIn(-1f, 1f)
                    bitsPerSample == 16 -> (buf.short.toFloat() / 32768f).coerceIn(-1f, 1f)
                    bitsPerSample == 24 -> {
                        val b0 = buf.get().toInt() and 0xFF
                        val b1 = buf.get().toInt() and 0xFF
                        val b2 = buf.get().toInt()
                        val signed24 = (b2 shl 16) or (b1 shl 8) or b0
                        (signed24 / 8388608f).coerceIn(-1f, 1f)
                    }
                    bitsPerSample == 8 -> (((buf.get().toInt() and 0xFF) - 128) / 128f).coerceIn(-1f, 1f)
                    else -> 0f
                }
                if (ch == 0) left = sample
                if (ch == 1) right = sample
            }
            if (numChannels == 1) right = left
            srcStereo[frame * 2] = left
            srcStereo[frame * 2 + 1] = right
        }

        val finalStereo = if (sampleRate == targetSampleRate) {
            srcStereo
        } else {
            resampleLinearStereo(srcStereo, sampleRate, targetSampleRate)
        }

        val outFrames = finalStereo.size / 2
        return DecodedWavAudio(
            interleavedStereo = finalStereo,
            sampleRate = targetSampleRate,
            durationSec = outFrames.toFloat() / targetSampleRate.toFloat()
        )
    }

    fun encodeStereoWavBytes(interleavedStereo: FloatArray, sampleRate: Int = 48000): ByteArray {
        val numFrames = interleavedStereo.size / 2
        val numChannels = 2
        val bitsPerSample = 16
        val byteRate = sampleRate * numChannels * (bitsPerSample / 8)
        val blockAlign = numChannels * (bitsPerSample / 8)
        val dataSize = numFrames * blockAlign

        val out = ByteArrayOutputStream(44 + dataSize)
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.putInt(0x46464952)
        header.putInt(36 + dataSize)
        header.putInt(0x45564157)
        header.putInt(0x20746d66)
        header.putInt(16)
        header.putShort(1)
        header.putShort(numChannels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(blockAlign.toShort())
        header.putShort(bitsPerSample.toShort())
        header.putInt(0x61746164)
        header.putInt(dataSize)
        out.write(header.array())

        val pcmBuf = ByteBuffer.allocate(dataSize).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until numFrames * 2) {
            val clamped = interleavedStereo[i].coerceIn(-1f, 1f)
            val s16 = (clamped * 32767f).toInt().toShort()
            pcmBuf.putShort(s16)
        }
        out.write(pcmBuf.array())
        return out.toByteArray()
    }

    fun writeWavToUri(context: Context, uri: Uri, interleavedStereo: FloatArray, sampleRate: Int = 48000): Boolean {
        return try {
            val bytes = encodeStereoWavBytes(interleavedStereo, sampleRate)
            context.contentResolver.openOutputStream(uri)?.use { stream ->
                stream.write(bytes)
                stream.flush()
            } != null
        } catch (_: Exception) {
            false
        }
    }

    private fun resampleLinearStereo(src: FloatArray, srcRate: Int, dstRate: Int): FloatArray {
        val srcFrames = src.size / 2
        if (srcFrames <= 1) return src
        val ratio = srcRate.toDouble() / dstRate.toDouble()
        val dstFrames = (srcFrames / ratio).toInt().coerceAtLeast(1)
        val dst = FloatArray(dstFrames * 2)

        for (i in 0 until dstFrames) {
            val srcPos = i * ratio
            val idx0 = srcPos.toInt().coerceIn(0, srcFrames - 1)
            val idx1 = (idx0 + 1).coerceIn(0, srcFrames - 1)
            val frac = (srcPos - idx0).toFloat()

            val l0 = src[idx0 * 2]
            val r0 = src[idx0 * 2 + 1]
            val l1 = src[idx1 * 2]
            val r1 = src[idx1 * 2 + 1]

            dst[i * 2] = l0 + (l1 - l0) * frac
            dst[i * 2 + 1] = r0 + (r1 - r0) * frac
        }
        return dst
    }
}
