package com.digitaldelay6.app.audio

import com.digitaldelay6.app.model.Dd6Mode
import com.digitaldelay6.app.model.HoldLoopState
import java.util.concurrent.atomic.AtomicLong

data class EngineStatusMetrics(
    val inputRms: Float,
    val outputRms: Float,
    val outputPeak: Float,
    val sampleRateHz: Int,
    val burstFrames: Int,
    val holdProgress: Float,
    val holdDurationSec: Float,
    val importedProgress: Float
)

class NativeDelayEngine {

    private val handle = AtomicLong(0L)
    private val metricsBuffer = FloatArray(8)
    private val waveformBuffer = FloatArray(128)

    init {
        handle.set(nativeCreateEngine())
    }

    fun start(): Boolean {
        val ptr = handle.get()
        return if (ptr != 0L) nativeStartEngine(ptr) else false
    }

    fun stop() {
        val ptr = handle.get()
        if (ptr != 0L) nativeStopEngine(ptr)
    }

    fun destroy() {
        val ptr = handle.getAndSet(0L)
        if (ptr != 0L) nativeDestroyEngine(ptr)
    }

    fun setEffectLevel(level: Float) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetEffectLevel(ptr, level.coerceIn(0f, 1f))
    }

    fun setFeedback(feedback: Float) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetFeedback(ptr, feedback.coerceIn(0f, 0.96f))
    }

    fun setDelayTimeMs(timeMs: Float) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetDelayTimeMs(ptr, timeMs.coerceIn(1f, 2600f))
    }

    fun setMode(mode: Dd6Mode) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetMode(ptr, mode.ordinalId)
    }

    fun setBypass(bypassed: Boolean) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetBypass(ptr, bypassed)
    }

    fun setPedalHeld(held: Boolean) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetPedalHeld(ptr, held)
    }

    fun setHoldState(state: HoldLoopState) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetHoldState(ptr, state.ordinalId)
    }

    fun clearHoldLoop() {
        val ptr = handle.get()
        if (ptr != 0L) nativeClearHoldLoop(ptr)
    }

    fun setInputEnabled(enabled: Boolean) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetInputEnabled(ptr, enabled)
    }

    fun triggerTestPluck(frequencyHz: Float) {
        val ptr = handle.get()
        if (ptr != 0L) nativeTriggerTestPluck(ptr, frequencyHz)
    }

    fun loadImportedAudio(interleavedStereo: FloatArray?) {
        val ptr = handle.get()
        if (ptr != 0L) nativeLoadImportedAudio(ptr, interleavedStereo)
    }

    fun setImportedPlayback(playing: Boolean, looping: Boolean = true) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetImportedPlayback(ptr, playing, looping)
    }

    fun seekImported(position01: Float) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSeekImported(ptr, position01.coerceIn(0f, 1f))
    }

    fun setRecording(recording: Boolean) {
        val ptr = handle.get()
        if (ptr != 0L) nativeSetRecording(ptr, recording)
    }

    fun getRecordedPcm(): FloatArray {
        val ptr = handle.get()
        return if (ptr != 0L) nativeGetRecordedPcm(ptr) else FloatArray(0)
    }

    fun renderProcessedOffline(inInterleavedStereo: FloatArray): FloatArray {
        val ptr = handle.get()
        return if (ptr != 0L) nativeRenderProcessedOffline(ptr, inInterleavedStereo) else FloatArray(0)
    }

    fun pollMetrics(): EngineStatusMetrics {
        val ptr = handle.get()
        if (ptr == 0L) {
            return EngineStatusMetrics(0f, 0f, 0f, 48000, 192, 0f, 0f, 0f)
        }
        nativeGetStatusMetrics(ptr, metricsBuffer)
        return EngineStatusMetrics(
            inputRms = metricsBuffer[0],
            outputRms = metricsBuffer[1],
            outputPeak = metricsBuffer[2],
            sampleRateHz = metricsBuffer[3].toInt().coerceAtLeast(8000),
            burstFrames = metricsBuffer[4].toInt().coerceAtLeast(32),
            holdProgress = metricsBuffer[5],
            holdDurationSec = metricsBuffer[6],
            importedProgress = metricsBuffer[7]
        )
    }

    fun pollWaveform(): List<Float> {
        val ptr = handle.get()
        if (ptr == 0L) return emptyList()
        nativeGetWaveform(ptr, waveformBuffer)
        return waveformBuffer.toList()
    }

    private external fun nativeCreateEngine(): Long
    private external fun nativeDestroyEngine(handle: Long)
    private external fun nativeStartEngine(handle: Long): Boolean
    private external fun nativeStopEngine(handle: Long)
    private external fun nativeSetEffectLevel(handle: Long, level: Float)
    private external fun nativeSetFeedback(handle: Long, feedback: Float)
    private external fun nativeSetDelayTimeMs(handle: Long, timeMs: Float)
    private external fun nativeSetMode(handle: Long, modeOrdinal: Int)
    private external fun nativeSetBypass(handle: Long, bypassed: Boolean)
    private external fun nativeSetPedalHeld(handle: Long, held: Boolean)
    private external fun nativeSetHoldState(handle: Long, holdStateOrdinal: Int)
    private external fun nativeClearHoldLoop(handle: Long)
    private external fun nativeSetInputEnabled(handle: Long, enabled: Boolean)
    private external fun nativeTriggerTestPluck(handle: Long, frequencyHz: Float)
    private external fun nativeLoadImportedAudio(handle: Long, interleavedStereo: FloatArray?)
    private external fun nativeSetImportedPlayback(handle: Long, playing: Boolean, looping: Boolean)
    private external fun nativeSeekImported(handle: Long, pos01: Float)
    private external fun nativeSetRecording(handle: Long, recording: Boolean)
    private external fun nativeGetRecordedPcm(handle: Long): FloatArray
    private external fun nativeRenderProcessedOffline(handle: Long, inInterleavedStereo: FloatArray): FloatArray
    private external fun nativeGetStatusMetrics(handle: Long, outMetrics: FloatArray)
    private external fun nativeGetWaveform(handle: Long, outSamples: FloatArray)

    companion object {
        init {
            System.loadLibrary("digitaldelay6")
        }
    }
}
