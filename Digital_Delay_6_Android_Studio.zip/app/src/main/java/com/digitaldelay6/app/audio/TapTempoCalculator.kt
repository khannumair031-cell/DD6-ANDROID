package com.digitaldelay6.app.audio

data class TapTempoResult(
    val delayMs: Float,
    val bpm: Float
)

class TapTempoCalculator(
    private val maxTapGapMs: Long = 2600L,
    private val windowSize: Int = 4
) {
    private val tapTimestampsMs = ArrayDeque<Long>()

    fun recordTap(nowMs: Long, minMs: Float = 1f, maxMs: Float = 2600f): TapTempoResult? {
        val lastTap = tapTimestampsMs.lastOrNull()
        if (lastTap != null && (nowMs - lastTap) > maxTapGapMs) {
            tapTimestampsMs.clear()
        }

        if (lastTap != null && nowMs <= lastTap) {
            return null
        }

        tapTimestampsMs.addLast(nowMs)
        while (tapTimestampsMs.size > windowSize) {
            tapTimestampsMs.removeFirst()
        }

        if (tapTimestampsMs.size < 2) {
            return null
        }

        val totalSpanMs = (tapTimestampsMs.last() - tapTimestampsMs.first()).toFloat()
        val intervals = (tapTimestampsMs.size - 1).toFloat()
        val avgMs = (totalSpanMs / intervals).coerceIn(minMs, maxMs)
        val bpm = 60_000f / avgMs

        return TapTempoResult(
            delayMs = avgMs,
            bpm = bpm
        )
    }

    fun reset() {
        tapTimestampsMs.clear()
    }
}
