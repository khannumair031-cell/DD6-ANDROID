package com.digitaldelay6.app.ui.screen

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.digitaldelay6.app.R
import com.digitaldelay6.app.model.Dd6Mode
import com.digitaldelay6.app.ui.components.DelayVisualizer
import com.digitaldelay6.app.ui.components.RotaryKnob
import com.digitaldelay6.app.ui.theme.BossBlue
import com.digitaldelay6.app.ui.theme.BossBlueDeep
import com.digitaldelay6.app.ui.theme.CheckLedRed
import com.digitaldelay6.app.ui.theme.FaceplateBlack
import com.digitaldelay6.app.ui.theme.PedalCream
import com.digitaldelay6.app.ui.theme.PedalCreamDark
import com.digitaldelay6.app.viewmodel.DelayViewModel
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DelayPedalScreen(
    viewModel: DelayViewModel,
    onRequestMicPermission: () -> Unit,
    onImportAudioClick: () -> Unit,
    onExportAudioClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val haptic = LocalHapticFeedback.current

    var showSplash by remember { mutableStateOf(true) }
    var splashStarted by remember { mutableStateOf(false) }

    val splashScale by animateFloatAsState(
        targetValue = if (splashStarted) 1f else 0.72f,
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "splashScale"
    )
    val splashAlpha by animateFloatAsState(
        targetValue = if (splashStarted) 1f else 0f,
        animationSpec = tween(durationMillis = 550),
        label = "splashAlpha"
    )

    LaunchedEffect(Unit) {
        splashStarted = true
        delay(1250L)
        showSplash = false
    }

    val infiniteTransition = rememberInfiniteTransition(label = "tempoLed")
    val tempoBlinkAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 280),
            repeatMode = RepeatMode.Reverse
        ),
        label = "tempoBlinkAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF060911), Color(0xFF0D1422), Color(0xFF060911))
                )
            )
            .systemBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.dd6_official_logo),
                        contentDescription = "Official DD-6 Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.5.dp, BossBlue, RoundedCornerShape(10.dp))
                    )
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Digital Delay",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontStyle = FontStyle.Italic,
                                color = Color.White
                            )
                            Text(
                                text = "DD-6",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = BossBlue
                            )
                        }
                        Text(
                            text = state.statusBanner,
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8),
                            maxLines = 1
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(
                        onClick = {
                            if (!state.hasMicPermission) {
                                onRequestMicPermission()
                            } else {
                                viewModel.toggleMicInput(!state.isMicInputEnabled)
                            }
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (state.isMicInputEnabled) Color(0xFF10B981).copy(alpha = 0.22f)
                                else Color(0xFF161F30)
                            )
                    ) {
                        Icon(
                            imageVector = if (state.isMicInputEnabled) Icons.Rounded.Mic else Icons.Rounded.MicOff,
                            contentDescription = "Live Microphone Input",
                            tint = if (state.isMicInputEnabled) Color(0xFF34D399) else Color(0xFF94A3B8)
                        )
                    }

                    IconButton(
                        onClick = {
                            if (state.isEngineRunning) viewModel.stopEngine() else viewModel.startEngine()
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (state.isEngineRunning) BossBlue.copy(alpha = 0.22f)
                                else Color(0xFF161F30)
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PowerSettingsNew,
                            contentDescription = "Audio Engine Power",
                            tint = if (state.isEngineRunning) BossBlue else Color(0xFF64748B)
                        )
                    }
                }
            }

            DelayVisualizer(state = state)

            Surface(
                shape = RoundedCornerShape(22.dp),
                color = PedalCream,
                border = BorderStroke(2.dp, BossBlue.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(14.dp, RoundedCornerShape(22.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(PedalCream, PedalCreamDark)
                            )
                        )
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(FaceplateBlack)
                            .border(1.5.dp, Color(0xFF2B3548), RoundedCornerShape(14.dp))
                            .padding(horizontal = 10.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "CHECK",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                val ledActive = !state.isBypassed
                                val ledColor = when {
                                    state.isTempoModeActive -> Color(0xFF22C55E).copy(alpha = tempoBlinkAlpha)
                                    ledActive -> CheckLedRed
                                    else -> Color(0xFF334155)
                                }
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(ledColor)
                                        .border(1.dp, Color(0xFF64748B), CircleShape)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RotaryKnob(
                                label = "E.LEVEL",
                                value = state.effectLevel,
                                defaultValue = 0.50f,
                                valueText = "${(state.effectLevel * 100).toInt()}%",
                                accentColor = BossBlue,
                                knobSize = 62.dp,
                                onValueChange = { viewModel.setEffectLevel(it) },
                                modifier = Modifier.weight(1f)
                            )

                            RotaryKnob(
                                label = "F.BACK",
                                value = (state.feedback / 0.96f).coerceIn(0f, 1f),
                                defaultValue = 0.45f / 0.96f,
                                valueText = "${(state.feedback * 100).toInt()}%",
                                accentColor = BossBlue,
                                knobSize = 62.dp,
                                onValueChange = { viewModel.setFeedback(it * 0.96f) },
                                modifier = Modifier.weight(1f)
                            )

                            val normTime = (
                                (state.delayTimeMs - state.mode.minDelayMs) /
                                    (state.mode.maxDelayMs - state.mode.minDelayMs).coerceAtLeast(1f)
                                ).coerceIn(0f, 1f)

                            RotaryKnob(
                                label = "D.TIME",
                                value = normTime,
                                defaultValue = (
                                    (state.mode.defaultDelayMs - state.mode.minDelayMs) /
                                        (state.mode.maxDelayMs - state.mode.minDelayMs).coerceAtLeast(1f)
                                    ).coerceIn(0f, 1f),
                                valueText = "${state.delayTimeMs.toInt()}ms",
                                accentColor = BossBlue,
                                knobSize = 62.dp,
                                onValueChange = { norm ->
                                    val ms = state.mode.minDelayMs +
                                        norm * (state.mode.maxDelayMs - state.mode.minDelayMs)
                                    viewModel.setDelayTimeMs(ms)
                                },
                                modifier = Modifier.weight(1f)
                            )

                            val modeNorm = state.mode.ordinalId.toFloat() / (Dd6Mode.entries.size - 1).toFloat()
                            RotaryKnob(
                                label = "MODE",
                                value = modeNorm,
                                defaultValue = 2f / 6f,
                                valueText = state.mode.dialLabel,
                                accentColor = state.mode.accentColor,
                                steps = Dd6Mode.entries.size,
                                knobSize = 62.dp,
                                onValueChange = { norm ->
                                    val idx = (norm * (Dd6Mode.entries.size - 1))
                                        .roundToInt()
                                        .coerceIn(0, Dd6Mode.entries.size - 1)
                                    val selectedMode = Dd6Mode.entries[idx]
                                    if (selectedMode != state.mode) {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        viewModel.setMode(selectedMode)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Dd6Mode.entries.forEach { mode ->
                                val selected = state.mode == mode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(
                                            if (selected) mode.accentColor else Color(0xFF1E2636)
                                        )
                                        .border(
                                            1.dp,
                                            if (selected) Color.White else Color(0xFF334155),
                                            RoundedCornerShape(7.dp)
                                        )
                                        .clickable {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            viewModel.setMode(mode)
                                        }
                                        .padding(horizontal = 8.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        text = mode.dialLabel,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        color = if (selected) Color(0xFF04101A) else Color(0xFFCBD5E1)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "SET TEMPO : PRESS & HOLD (>2 sec.)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp,
                            color = Color(0xFFCBD5E1),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = "Digital Delay",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontStyle = FontStyle.Italic,
                                color = BossBlueDeep
                            )
                            Text(
                                text = "DD-6",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black,
                                color = BossBlueDeep
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            val notes = listOf(
                                "E2" to 82.41f,
                                "A2" to 110.00f,
                                "D3" to 146.83f,
                                "G3" to 196.00f,
                                "B3" to 246.94f,
                                "E4" to 329.63f
                            )
                            notes.forEach { (note, freq) ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(Color(0xFF1A2232))
                                        .clickable {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            viewModel.triggerPluck(freq)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = note,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(106.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF181D26), Color(0xFF0C0F14))
                                )
                            )
                            .border(
                                width = 2.dp,
                                color = if (state.isPedalHeld) BossBlue else Color(0xFF2E3748),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = {
                                        viewModel.onFootswitchPressDown()
                                        tryAwaitRelease()
                                        viewModel.onFootswitchRelease()
                                    },
                                    onTap = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.onFootswitchTap()
                                    },
                                    onLongPress = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.onFootswitchHoldTwoSeconds()
                                    }
                                )
                            }
                            .padding(10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "DD-6",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                fontStyle = FontStyle.Italic,
                                letterSpacing = 1.5.sp,
                                color = Color(0xFFE2E8F0)
                            )
                            Text(
                                text = when {
                                    state.mode == Dd6Mode.HOLD_52S -> "TAP: ${state.holdLoopState.badgeText}  •  HOLD: CLEAR"
                                    state.isTempoModeActive -> "TAP TEMPO ACTIVE  •  HOLD >2s TO EXIT"
                                    state.isBypassed -> "BYPASSED (TAP FOOTSWITCH FOR ON)"
                                    else -> "EFFECT ON (TAP: BYPASS • HOLD >2s: TEMPO/WARP)"
                                },
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = BossBlue
                            )
                        }
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF101622),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DD-6 AUDIO RECORDER, IMPORT & EXPORT",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.7.sp,
                            color = Color(0xFF94A3B8)
                        )
                        if (state.importedFileName != null) {
                            Text(
                                text = state.importedFileName!!,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF38BDF8),
                                maxLines = 1
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StudioActionButton(
                            label = if (state.isRecordingOutput) "STOP REC" else "REC WAV",
                            accent = if (state.isRecordingOutput) CheckLedRed else Color(0xFF38BDF8),
                            active = state.isRecordingOutput,
                            onClick = { viewModel.toggleOutputRecording() },
                            modifier = Modifier.weight(1f)
                        ) {
                            if (state.isRecordingOutput) {
                                Icon(Icons.Rounded.Stop, contentDescription = null, tint = CheckLedRed, modifier = Modifier.size(16.dp))
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(CheckLedRed)
                                )
                            }
                        }

                        StudioActionButton(
                            label = if (state.isImportedPlaying) "PAUSE" else "PLAY",
                            accent = Color(0xFF10B981),
                            active = state.isImportedPlaying,
                            onClick = {
                                if (state.importedFileName != null) {
                                    viewModel.toggleImportedPlayback()
                                } else if (state.hasRecordedTake) {
                                    viewModel.playRecordedTake()
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (state.isImportedPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        StudioActionButton(
                            label = "IMPORT",
                            accent = Color(0xFFF59E0B),
                            active = false,
                            onClick = onImportAudioClick,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FolderOpen,
                                contentDescription = null,
                                tint = Color(0xFFF59E0B),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        StudioActionButton(
                            label = "EXPORT",
                            accent = BossBlue,
                            active = false,
                            onClick = onExportAudioClick,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = null,
                                tint = BossBlue,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showSplash,
            exit = fadeOut(animationSpec = tween(durationMillis = 350)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF02050A)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier
                        .scale(splashScale)
                        .alpha(splashAlpha)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.dd6_official_logo),
                        contentDescription = "Digital Delay DD-6 Opening Logo",
                        modifier = Modifier
                            .size(180.dp)
                            .clip(RoundedCornerShape(32.dp))
                            .border(2.dp, BossBlue, RoundedCornerShape(32.dp))
                    )
                    Text(
                        text = "DIGITAL DELAY DD-6",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        color = Color.White
                    )
                    Text(
                        text = "REAL-TIME C++20 OBOE DSP ENGINE",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = BossBlue
                    )
                }
            }
        }
    }
}

@Composable
private fun StudioActionButton(
    label: String,
    accent: Color,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit
) {
    Row(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(if (active) accent.copy(alpha = 0.2f) else Color(0xFF172030))
            .border(1.dp, if (active) accent else Color(0xFF283548), RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(modifier = Modifier.size(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1
        )
    }
}
