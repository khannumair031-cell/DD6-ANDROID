package com.digitaldelay6.app

import android.app.Application
import android.util.Log

class DigitalDelayApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("DigitalDelay6", "Digital Delay 6 (DD-6) Application initialized")
    }
}
