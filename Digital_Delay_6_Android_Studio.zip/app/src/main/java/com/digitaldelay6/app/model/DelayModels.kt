package com.digitaldelay6.app.model

import androidx.compose.ui.graphics.Color

enum class Dd6Mode(
    val ordinalId: Int,
    val dialLabel: String,
    val title: String,
    val subtitle: String,
    val minDelayMs: Float,
    val maxDelayMs: Float,
    val defaultDelayMs: Float,
    val accentColor: Color
) {
    MODE_80MS(
        ordinalId = 0,
        dialLabel = "80ms",
        title = "80ms Short Delay",
        subtitle = "1ms - 80ms crisp slapback & stereo doubling",
        minDelayMs = 1f,
        maxDelayMs = 80f,
        defaultDelayMs = 55f,
        accentColor = Color(0xFF38BDF8)
    ),
    MODE_300MS(
        ordinalId = 1,
        dialLabel = "300ms",
        title = "300ms Medium Delay",
        subtitle = "20ms - 300ms classic lead & vocal echo",
        minDelayMs = 20f,
        maxDelayMs = 300f,
        defaultDelayMs = 220f,
        accentColor = Color(0xFF0EA5E9)
    ),
    MODE_800MS(
        ordinalId = 2,
        dialLabel = "800ms",
        title = "800ms Studio Delay",
        subtitle = "50ms - 800ms standard digital delay",
        minDelayMs = 50f,
        maxDelayMs = 800f,
        defaultDelayMs = 420f,
        accentColor = Color(0xFF2563EB)
    ),
    MODE_2600MS(
        ordinalId = 3,
        dialLabel = "2600ms",
        title = "2600ms Long Delay",
        subtitle = "100ms - 2600ms expansive ambient repeats",
        minDelayMs = 100f,
        maxDelayMs = 2600f,
        defaultDelayMs = 1250f,
        accentColor = Color(0xFF6366F1)
    ),
    WARP(
        ordinalId = 4,
        dialLabel = "WARP",
        title = "WARP Infinite Swell",
        subtitle = "Hold footswitch to swell E.LEVEL & infinite feedback",
        minDelayMs = 50f,
        maxDelayMs = 2600f,
        defaultDelayMs = 480f,
        accentColor = Color(0xFFF59E0B)
    ),
    HOLD_52S(
        ordinalId = 5,
        dialLabel = "HOLD (5.2s)",
        title = "HOLD 5.2s Phrase Looper",
        subtitle = "Record & overdub up to 5.2 seconds of stereo audio",
        minDelayMs = 100f,
        maxDelayMs = 5200f,
        defaultDelayMs = 5200f,
        accentColor = Color(0xFF10B981)
    ),
    REVERSE(
        ordinalId = 6,
        dialLabel = "REVERSE",
        title = "REVERSE Backward Echo",
        subtitle = "Dual-head crossfaded backward echo playback",
        minDelayMs = 40f,
        maxDelayMs = 2600f,
        defaultDelayMs = 640f,
        accentColor = Color(0xFFEC4899)
    )
}

enum class HoldLoopState(val ordinalId: Int, val badgeText: String) {
    IDLE(0, "READY TO REC"),
    RECORDING(1, "RECORDING LOOP"),
    PLAYING(2, "LOOP PLAYING"),
    OVERDUBBING(3, "OVERDUBBING")
}

data class DelayUiState(
    val isEngineRunning: Boolean = false,
    val isBypassed: Boolean = false,
    val isPedalHeld: Boolean = false,
    val isTempoModeActive: Boolean = false,
    val isMicInputEnabled: Boolean = false,
    val hasMicPermission: Boolean = false,

    val effectLevel: Float = 0.50f,
    val feedback: Float = 0.45f,
    val delayTimeMs: Float = 420f,
    val mode: Dd6Mode = Dd6Mode.MODE_800MS,

    val holdLoopState: HoldLoopState = HoldLoopState.IDLE,
    val holdProgress: Float = 0f,
    val holdDurationSec: Float = 0f,

    val isRecordingOutput: Boolean = false,
    val hasRecordedTake: Boolean = false,
    val recordedTakeDurationSec: Float = 0f,
    val importedFileName: String? = null,
    val isImportedPlaying: Boolean = false,
    val importedProgress: Float = 0f,
    val statusBanner: String = "DD-6 DSP Ready • 48kHz Low-Latency",

    val bpm: Float = 142.9f,
    val inputRms: Float = 0f,
    val outputRms: Float = 0f,
    val outputPeak: Float = 0f,
    val sampleRateHz: Int = 48000,
    val burstFrames: Int = 192,
    val waveform: List<Float> = List(128) { 0f }
)
