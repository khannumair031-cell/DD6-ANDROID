#pragma once

#include "BiquadFilter.h"
#include <vector>
#include <cstdint>

namespace digitaldelay6 {

enum class Dd6Mode : int32_t {
    Delay80ms = 0,
    Delay300ms = 1,
    Delay800ms = 2,
    Delay2600ms = 3,
    Warp = 4,
    Hold5200ms = 5,
    Reverse = 6
};

enum class HoldState : int32_t {
    Idle = 0,
    Recording = 1,
    Playing = 2,
    Overdubbing = 3
};

struct DelayParameters {
    float effectLevel = 0.50f;
    float feedback = 0.45f;
    float delayTimeMs = 420.0f;
    Dd6Mode mode = Dd6Mode::Delay800ms;
    bool bypassed = false;
    bool pedalHeld = false;
    HoldState holdState = HoldState::Idle;
};

class DelayDspProcessor {
public:
    static constexpr float kMaxDelaySeconds = 3.0f;
    static constexpr float kMaxHoldSeconds = 5.2f;

    DelayDspProcessor();

    void prepare(float sampleRate);
    void reset();
    void clearHoldLoop() noexcept;

    void triggerPluck(float frequencyHz) noexcept;

    float getHoldProgress() const noexcept;
    float getHoldDurationSeconds() const noexcept;

    void processStereoBlock(
        const float* inLeft,
        const float* inRight,
        float* outLeft,
        float* outRight,
        int32_t numFrames,
        const DelayParameters& params
    ) noexcept;

private:
    float readHermite(const std::vector<float>& buffer, float delaySamples) const noexcept;

    float sampleRate_ = 48000.0f;
    int32_t bufferSize_ = 150000;
    int32_t writeIndex_ = 0;

    std::vector<float> delayBufferL_;
    std::vector<float> delayBufferR_;

    int32_t maxHoldSamples_ = 249600;
    int32_t holdLoopLength_ = 0;
    int32_t holdCursor_ = 0;
    std::vector<float> holdBufferL_;
    std::vector<float> holdBufferR_;

    float smoothedDelaySamples_ = 20160.0f;
    float smoothedFeedback_ = 0.45f;
    float smoothedMix_ = 0.50f;
    float warpEnvelope_ = 0.0f;
    float reversePhase_ = 0.0f;

    BiquadFilter dampingFilterL_;
    BiquadFilter dampingFilterR_;
    BiquadFilter dcBlockFilterL_;
    BiquadFilter dcBlockFilterR_;

    float synthPhase_ = 0.0f;
    float synthFreq_ = 220.0f;
    float synthEnv_ = 0.0f;
};

} // namespace digitaldelay6
