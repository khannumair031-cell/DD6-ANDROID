#pragma once

#include "DelayDspProcessor.h"
#include <oboe/Oboe.h>
#include <atomic>
#include <memory>
#include <mutex>
#include <vector>

namespace digitaldelay6 {

class DelayAudioEngine : public oboe::AudioStreamDataCallback,
                         public oboe::AudioStreamErrorCallback {
public:
    static constexpr int32_t kWaveformSize = 256;

    DelayAudioEngine();
    ~DelayAudioEngine() override;

    bool start();
    void stop();

    void setEffectLevel(float level) noexcept { effectLevel_.store(level, std::memory_order_relaxed); }
    void setFeedback(float feedback) noexcept { feedback_.store(feedback, std::memory_order_relaxed); }
    void setDelayTimeMs(float timeMs) noexcept { delayTimeMs_.store(timeMs, std::memory_order_relaxed); }
    void setMode(int32_t modeOrdinal) noexcept { modeOrdinal_.store(modeOrdinal, std::memory_order_relaxed); }
    void setBypass(bool bypassed) noexcept { bypassed_.store(bypassed, std::memory_order_relaxed); }
    void setPedalHeld(bool held) noexcept { pedalHeld_.store(held, std::memory_order_relaxed); }
    void setHoldState(int32_t stateOrdinal) noexcept { holdStateOrdinal_.store(stateOrdinal, std::memory_order_relaxed); }
    void clearHoldLoop() noexcept;

    void setInputEnabled(bool enabled) noexcept;
    void triggerTestPluck(float frequencyHz) noexcept;

    void loadImportedAudio(const float* interleavedStereo, int32_t numFrames);
    void setImportedPlayback(bool playing, bool looping) noexcept;
    void seekImportedNormalized(float position01) noexcept;

    void setRecording(bool recording);
    std::vector<float> getRecordedStereoPcm() const;
    std::vector<float> renderProcessedOffline(const float* inInterleavedStereo, int32_t numFrames);

    void getStatusMetrics(float* outEightFloats) const noexcept;
    void getWaveform(float* outSamples, int32_t count) const noexcept;

    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* audioStream,
        void* audioData,
        int32_t numFrames
    ) override;

    void onErrorAfterClose(oboe::AudioStream* audioStream, oboe::Result error) override;

private:
    bool openOutputStream();
    bool openInputStream();
    void closeStreams();

    std::shared_ptr<oboe::AudioStream> outputStream_;
    std::shared_ptr<oboe::AudioStream> inputStream_;

    DelayDspProcessor dspProcessor_;

    static constexpr int32_t kMaxCallbackFrames = 4096;
    std::vector<float> scratchInL_;
    std::vector<float> scratchInR_;
    std::vector<float> scratchOutL_;
    std::vector<float> scratchOutR_;
    std::vector<float> inputCaptureScratch_;

    mutable std::mutex importedMutex_;
    std::vector<float> importedLeft_;
    std::vector<float> importedRight_;
    std::atomic<int32_t> importedPlayIndex_{0};
    std::atomic<bool> importedPlaying_{false};
    std::atomic<bool> importedLooping_{true};

    mutable std::mutex recordMutex_;
    std::vector<float> recordedInterleaved_;
    std::atomic<bool> isRecording_{false};

    std::atomic<float> effectLevel_{0.50f};
    std::atomic<float> feedback_{0.45f};
    std::atomic<float> delayTimeMs_{420.0f};
    std::atomic<int32_t> modeOrdinal_{2};
    std::atomic<bool> bypassed_{false};
    std::atomic<bool> pedalHeld_{false};
    std::atomic<int32_t> holdStateOrdinal_{0};
    std::atomic<bool> inputEnabled_{false};
    std::atomic<bool> pendingClearHold_{false};

    std::atomic<float> pendingPluckFreq_{0.0f};

    std::atomic<float> inputRms_{0.0f};
    std::atomic<float> outputRms_{0.0f};
    std::atomic<float> outputPeak_{0.0f};
    std::atomic<float> sampleRateHz_{48000.0f};
    std::atomic<float> framesPerBurst_{192.0f};

    std::atomic<float> waveformRing_[kWaveformSize]{};
    std::atomic<int32_t> waveformWritePos_{0};
};

} // namespace digitaldelay6
