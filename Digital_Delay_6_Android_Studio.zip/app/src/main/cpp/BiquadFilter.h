#pragma once

#include <cmath>

namespace digitaldelay6 {

enum class FilterType {
    LowPass,
    HighPass
};

class BiquadFilter {
public:
    BiquadFilter() = default;

    void configure(FilterType type, float sampleRate, float cutoffHz, float q = 0.70710678f);
    void reset() noexcept;

    inline float process(float input) noexcept {
        const float output = b0_ * input + z1_;
        z1_ = b1_ * input - a1_ * output + z2_;
        z2_ = b2_ * input - a2_ * output;
        return output;
    }

private:
    float b0_ = 1.0f;
    float b1_ = 0.0f;
    float b2_ = 0.0f;
    float a1_ = 0.0f;
    float a2_ = 0.0f;

    float z1_ = 0.0f;
    float z2_ = 0.0f;
};

} // namespace digitaldelay6
