#include "BiquadFilter.h"
#include <algorithm>

namespace digitaldelay6 {

namespace {
constexpr float kPi = 3.14159265358979323846f;
}

void BiquadFilter::configure(FilterType type, float sampleRate, float cutoffHz, float q) {
    const float safeSampleRate = std::max(8000.0f, sampleRate);
    const float nyquist = safeSampleRate * 0.48f;
    const float clampedCutoff = std::clamp(cutoffHz, 20.0f, nyquist);
    const float safeQ = std::max(0.1f, q);

    const float omega = 2.0f * kPi * clampedCutoff / safeSampleRate;
    const float sinOmega = std::sin(omega);
    const float cosOmega = std::cos(omega);
    const float alpha = sinOmega / (2.0f * safeQ);

    float b0 = 1.0f;
    float b1 = 0.0f;
    float b2 = 0.0f;
    const float a0 = 1.0f + alpha;
    const float a1 = -2.0f * cosOmega;
    const float a2 = 1.0f - alpha;

    if (type == FilterType::LowPass) {
        b0 = (1.0f - cosOmega) * 0.5f;
        b1 = 1.0f - cosOmega;
        b2 = (1.0f - cosOmega) * 0.5f;
    } else {
        b0 = (1.0f + cosOmega) * 0.5f;
        b1 = -(1.0f + cosOmega);
        b2 = (1.0f + cosOmega) * 0.5f;
    }

    const float invA0 = 1.0f / a0;
    b0_ = b0 * invA0;
    b1_ = b1 * invA0;
    b2_ = b2 * invA0;
    a1_ = a1 * invA0;
    a2_ = a2 * invA0;
}

void BiquadFilter::reset() noexcept {
    z1_ = 0.0f;
    z2_ = 0.0f;
}

} // namespace digitaldelay6
