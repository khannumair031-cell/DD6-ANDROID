#include "DelayDspProcessor.h"
#include <algorithm>
#include <cmath>

namespace digitaldelay6 {

namespace {
constexpr float kTwoPi = 6.28318530717958647692f;

inline float softLimit(float x) noexcept {
    return std::tanh(x * 1.15f);
}
} // namespace

DelayDspProcessor::DelayDspProcessor() {
    prepare(48000.0f);
}

void DelayDspProcessor::prepare(float sampleRate) {
    sampleRate_ = std::max(8000.0f, sampleRate);
    bufferSize_ = static_cast<int32_t>(sampleRate_ * kMaxDelaySeconds) + 2048;
    maxHoldSamples_ = static_cast<int32_t>(sampleRate_ * kMaxHoldSeconds);

    delayBufferL_.assign(static_cast<size_t>(bufferSize_), 0.0f);
    delayBufferR_.assign(static_cast<size_t>(bufferSize_), 0.0f);
    holdBufferL_.assign(static_cast<size_t>(maxHoldSamples_), 0.0f);
    holdBufferR_.assign(static_cast<size_t>(maxHoldSamples_), 0.0f);

    smoothedDelaySamples_ = sampleRate_ * 0.42f;
    dampingFilterL_.configure(FilterType::LowPass, sampleRate_, 9500.0f, 0.707f);
    dampingFilterR_.configure(FilterType::LowPass, sampleRate_, 9500.0f, 0.707f);
    dcBlockFilterL_.configure(FilterType::HighPass, sampleRate_, 35.0f, 0.707f);
    dcBlockFilterR_.configure(FilterType::HighPass, sampleRate_, 35.0f, 0.707f);

    reset();
}

void DelayDspProcessor::reset() {
    std::fill(delayBufferL_.begin(), delayBufferL_.end(), 0.0f);
    std::fill(delayBufferR_.begin(), delayBufferR_.end(), 0.0f);
    writeIndex_ = 0;
    reversePhase_ = 0.0f;
    warpEnvelope_ = 0.0f;
    synthEnv_ = 0.0f;
    dampingFilterL_.reset();
    dampingFilterR_.reset();
    dcBlockFilterL_.reset();
    dcBlockFilterR_.reset();
    clearHoldLoop();
}

void DelayDspProcessor::clearHoldLoop() noexcept {
    std::fill(holdBufferL_.begin(), holdBufferL_.end(), 0.0f);
    std::fill(holdBufferR_.begin(), holdBufferR_.end(), 0.0f);
    holdLoopLength_ = 0;
    holdCursor_ = 0;
}

void DelayDspProcessor::triggerPluck(float frequencyHz) noexcept {
    synthFreq_ = std::clamp(frequencyHz, 55.0f, 1760.0f);
    synthPhase_ = 0.0f;
    synthEnv_ = 0.78f;
}

float DelayDspProcessor::getHoldProgress() const noexcept {
    if (maxHoldSamples_ <= 0) return 0.0f;
    if (holdLoopLength_ > 0) {
        return static_cast<float>(holdCursor_) / static_cast<float>(holdLoopLength_);
    }
    return static_cast<float>(holdCursor_) / static_cast<float>(maxHoldSamples_);
}

float DelayDspProcessor::getHoldDurationSeconds() const noexcept {
    const int32_t samples = (holdLoopLength_ > 0) ? holdLoopLength_ : holdCursor_;
    return static_cast<float>(samples) / std::max(8000.0f, sampleRate_);
}

float DelayDspProcessor::readHermite(const std::vector<float>& buffer, float delaySamples) const noexcept {
    const float maxDelay = static_cast<float>(bufferSize_ - 4);
    const float clampedDelay = std::clamp(delaySamples, 1.0f, maxDelay);

    float readPos = static_cast<float>(writeIndex_) - clampedDelay;
    while (readPos < 0.0f) {
        readPos += static_cast<float>(bufferSize_);
    }

    const int32_t idx1 = static_cast<int32_t>(readPos) % bufferSize_;
    const float frac = readPos - std::floor(readPos);

    const int32_t idx0 = (idx1 - 1 + bufferSize_) % bufferSize_;
    const int32_t idx2 = (idx1 + 1) % bufferSize_;
    const int32_t idx3 = (idx1 + 2) % bufferSize_;

    const float y0 = buffer[idx0];
    const float y1 = buffer[idx1];
    const float y2 = buffer[idx2];
    const float y3 = buffer[idx3];

    const float c0 = y1;
    const float c1 = 0.5f * (y2 - y0);
    const float c2 = y0 - 2.5f * y1 + 2.0f * y2 - 0.5f * y3;
    const float c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);

    return ((c3 * frac + c2) * frac + c1) * frac + c0;
}

void DelayDspProcessor::processStereoBlock(
    const float* inLeft,
    const float* inRight,
    float* outLeft,
    float* outRight,
    int32_t numFrames,
    const DelayParameters& params
) noexcept {
    const float targetDelaySamples = std::clamp(
        (params.delayTimeMs * 0.001f) * sampleRate_,
        sampleRate_ * 0.001f,
        sampleRate_ * 2.600f
    );
    const float baseFeedback = std::clamp(params.feedback, 0.0f, 0.96f);
    const float baseMix = params.bypassed ? 0.0f : std::clamp(params.effectLevel, 0.0f, 1.0f);

    const float smoothCoeff = 1.0f - std::exp(-1.0f / (0.010f * sampleRate_));
    const float warpAttack = 1.0f - std::exp(-1.0f / (0.18f * sampleRate_));
    const float warpRelease = 1.0f - std::exp(-1.0f / (0.25f * sampleRate_));

    for (int32_t i = 0; i < numFrames; ++i) {
        smoothedDelaySamples_ += (targetDelaySamples - smoothedDelaySamples_) * smoothCoeff;
        smoothedFeedback_ += (baseFeedback - smoothedFeedback_) * smoothCoeff;
        smoothedMix_ += (baseMix - smoothedMix_) * smoothCoeff;

        const float targetWarp = (params.mode == Dd6Mode::Warp && params.pedalHeld && !params.bypassed)
            ? 1.0f
            : 0.0f;
        warpEnvelope_ += (targetWarp - warpEnvelope_) * ((targetWarp > warpEnvelope_) ? warpAttack : warpRelease);

        float synthSample = 0.0f;
        if (synthEnv_ > 0.00005f) {
            const float f1 = std::sin(kTwoPi * synthPhase_);
            const float f2 = 0.35f * std::sin(kTwoPi * 2.0f * synthPhase_);
            const float f3 = 0.14f * std::sin(kTwoPi * 3.0f * synthPhase_) * synthEnv_;
            synthSample = (f1 + f2 + f3) * synthEnv_ * 0.45f;

            synthPhase_ += synthFreq_ / sampleRate_;
            if (synthPhase_ >= 1.0f) synthPhase_ -= 1.0f;
            synthEnv_ *= std::exp(-1.0f / (0.14f * sampleRate_));
        }

        const float dryL = inLeft[i] + synthSample;
        const float dryR = inRight[i] + synthSample;

        float wetL = 0.0f;
        float wetR = 0.0f;

        if (params.mode == Dd6Mode::Hold5200ms) {
            if (params.holdState == HoldState::Recording) {
                if (holdCursor_ < maxHoldSamples_) {
                    holdBufferL_[holdCursor_] = dryL;
                    holdBufferR_[holdCursor_] = dryR;
                    holdCursor_++;
                    holdLoopLength_ = holdCursor_;
                }
                wetL = 0.0f;
                wetR = 0.0f;
            } else if ((params.holdState == HoldState::Playing || params.holdState == HoldState::Overdubbing) && holdLoopLength_ > 0) {
                wetL = holdBufferL_[holdCursor_];
                wetR = holdBufferR_[holdCursor_];

                if (params.holdState == HoldState::Overdubbing && !params.bypassed) {
                    holdBufferL_[holdCursor_] = softLimit(wetL + dryL);
                    holdBufferR_[holdCursor_] = softLimit(wetR + dryR);
                }

                holdCursor_++;
                if (holdCursor_ >= holdLoopLength_) {
                    holdCursor_ = 0;
                }
            }
        } else if (params.mode == Dd6Mode::Reverse) {
            const float windowLen = std::max(128.0f, smoothedDelaySamples_);
            reversePhase_ += 1.0f / windowLen;
            if (reversePhase_ >= 1.0f) reversePhase_ -= 1.0f;

            const float phaseA = reversePhase_;
            const float phaseB = (reversePhase_ + 0.5f >= 1.0f) ? (reversePhase_ - 0.5f) : (reversePhase_ + 0.5f);

            const float delayA = 2.0f + phaseA * (2.0f * windowLen);
            const float delayB = 2.0f + phaseB * (2.0f * windowLen);

            const float winA = 0.5f * (1.0f - std::cos(kTwoPi * phaseA));
            const float winB = 0.5f * (1.0f - std::cos(kTwoPi * phaseB));

            wetL = readHermite(delayBufferL_, delayA) * winA + readHermite(delayBufferL_, delayB) * winB;
            wetR = readHermite(delayBufferR_, delayA) * winA + readHermite(delayBufferR_, delayB) * winB;

            const float fbL = dcBlockFilterL_.process(dampingFilterL_.process(wetL));
            const float fbR = dcBlockFilterR_.process(dampingFilterR_.process(wetR));

            delayBufferL_[writeIndex_] = std::clamp(dryL + fbL * smoothedFeedback_, -1.4f, 1.4f);
            delayBufferR_[writeIndex_] = std::clamp(dryR + fbR * smoothedFeedback_, -1.4f, 1.4f);
            writeIndex_ = (writeIndex_ + 1) % bufferSize_;
        } else {
            wetL = readHermite(delayBufferL_, smoothedDelaySamples_);
            wetR = readHermite(delayBufferR_, smoothedDelaySamples_);

            float effectiveFeedback = smoothedFeedback_;
            if (params.mode == Dd6Mode::Warp) {
                effectiveFeedback = smoothedFeedback_ + (0.985f - smoothedFeedback_) * warpEnvelope_;
                wetL = softLimit(wetL * (1.0f + 0.25f * warpEnvelope_));
                wetR = softLimit(wetR * (1.0f + 0.25f * warpEnvelope_));
            }

            const float fbL = dcBlockFilterL_.process(dampingFilterL_.process(wetL));
            const float fbR = dcBlockFilterR_.process(dampingFilterR_.process(wetR));

            delayBufferL_[writeIndex_] = std::clamp(dryL + fbL * effectiveFeedback, -1.4f, 1.4f);
            delayBufferR_[writeIndex_] = std::clamp(dryR + fbR * effectiveFeedback, -1.4f, 1.4f);
            writeIndex_ = (writeIndex_ + 1) % bufferSize_;
        }

        float effectiveMix = smoothedMix_;
        if (params.mode == Dd6Mode::Warp && !params.bypassed) {
            effectiveMix = smoothedMix_ + (0.88f - smoothedMix_) * warpEnvelope_;
        } else if (params.mode == Dd6Mode::Hold5200ms && !params.bypassed &&
                   (params.holdState == HoldState::Playing || params.holdState == HoldState::Overdubbing)) {
            effectiveMix = std::max(smoothedMix_, 0.65f);
        }

        const float dryGain = (effectiveMix <= 0.5f) ? 1.0f : (1.0f - (effectiveMix - 0.5f) * 2.0f);
        const float wetGain = (effectiveMix <= 0.5f) ? (effectiveMix * 2.0f) : 1.0f;

        outLeft[i] = dryL * dryGain + wetL * wetGain;
        outRight[i] = dryR * dryGain + wetR * wetGain;
    }
}

} // namespace digitaldelay6
