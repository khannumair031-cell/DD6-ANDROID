#include <jni.h>
#include "DelayAudioEngine.h"

using digitaldelay6::DelayAudioEngine;

namespace {
inline DelayAudioEngine* fromHandle(jlong handle) {
    return reinterpret_cast<DelayAudioEngine*>(handle);
}
} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeCreateEngine(JNIEnv*, jobject) {
    return reinterpret_cast<jlong>(new DelayAudioEngine());
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeDestroyEngine(JNIEnv*, jobject, jlong handle) {
    if (auto* engine = fromHandle(handle)) {
        engine->stop();
        delete engine;
    }
}

JNIEXPORT jboolean JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeStartEngine(JNIEnv*, jobject, jlong handle) {
    auto* engine = fromHandle(handle);
    return (engine && engine->start()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeStopEngine(JNIEnv*, jobject, jlong handle) {
    if (auto* engine = fromHandle(handle)) engine->stop();
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetEffectLevel(JNIEnv*, jobject, jlong handle, jfloat level) {
    if (auto* engine = fromHandle(handle)) engine->setEffectLevel(level);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetFeedback(JNIEnv*, jobject, jlong handle, jfloat feedback) {
    if (auto* engine = fromHandle(handle)) engine->setFeedback(feedback);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetDelayTimeMs(JNIEnv*, jobject, jlong handle, jfloat timeMs) {
    if (auto* engine = fromHandle(handle)) engine->setDelayTimeMs(timeMs);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetMode(JNIEnv*, jobject, jlong handle, jint modeOrdinal) {
    if (auto* engine = fromHandle(handle)) engine->setMode(modeOrdinal);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetBypass(JNIEnv*, jobject, jlong handle, jboolean bypassed) {
    if (auto* engine = fromHandle(handle)) engine->setBypass(bypassed == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetPedalHeld(JNIEnv*, jobject, jlong handle, jboolean held) {
    if (auto* engine = fromHandle(handle)) engine->setPedalHeld(held == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetHoldState(JNIEnv*, jobject, jlong handle, jint holdStateOrdinal) {
    if (auto* engine = fromHandle(handle)) engine->setHoldState(holdStateOrdinal);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeClearHoldLoop(JNIEnv*, jobject, jlong handle) {
    if (auto* engine = fromHandle(handle)) engine->clearHoldLoop();
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetInputEnabled(JNIEnv*, jobject, jlong handle, jboolean enabled) {
    if (auto* engine = fromHandle(handle)) engine->setInputEnabled(enabled == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeTriggerTestPluck(JNIEnv*, jobject, jlong handle, jfloat freqHz) {
    if (auto* engine = fromHandle(handle)) engine->triggerTestPluck(freqHz);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeLoadImportedAudio(
    JNIEnv* env,
    jobject,
    jlong handle,
    jfloatArray interleavedStereo
) {
    auto* engine = fromHandle(handle);
    if (!engine) return;
    if (!interleavedStereo) {
        engine->loadImportedAudio(nullptr, 0);
        return;
    }
    const jsize len = env->GetArrayLength(interleavedStereo);
    jfloat* ptr = env->GetFloatArrayElements(interleavedStereo, nullptr);
    if (ptr) {
        engine->loadImportedAudio(ptr, len / 2);
        env->ReleaseFloatArrayElements(interleavedStereo, ptr, JNI_ABORT);
    }
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetImportedPlayback(
    JNIEnv*,
    jobject,
    jlong handle,
    jboolean playing,
    jboolean looping
) {
    if (auto* engine = fromHandle(handle)) {
        engine->setImportedPlayback(playing == JNI_TRUE, looping == JNI_TRUE);
    }
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSeekImported(JNIEnv*, jobject, jlong handle, jfloat pos01) {
    if (auto* engine = fromHandle(handle)) {
        engine->seekImportedNormalized(pos01);
    }
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeSetRecording(JNIEnv*, jobject, jlong handle, jboolean rec) {
    if (auto* engine = fromHandle(handle)) {
        engine->setRecording(rec == JNI_TRUE);
    }
}

JNIEXPORT jfloatArray JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeGetRecordedPcm(JNIEnv* env, jobject, jlong handle) {
    auto* engine = fromHandle(handle);
    if (!engine) return env->NewFloatArray(0);
    auto pcm = engine->getRecordedStereoPcm();
    jfloatArray out = env->NewFloatArray(static_cast<jsize>(pcm.size()));
    if (out && !pcm.empty()) {
        env->SetFloatArrayRegion(out, 0, static_cast<jsize>(pcm.size()), pcm.data());
    }
    return out;
}

JNIEXPORT jfloatArray JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeRenderProcessedOffline(
    JNIEnv* env,
    jobject,
    jlong handle,
    jfloatArray inInterleavedStereo
) {
    auto* engine = fromHandle(handle);
    if (!engine || !inInterleavedStereo) return env->NewFloatArray(0);
    const jsize len = env->GetArrayLength(inInterleavedStereo);
    jfloat* inPtr = env->GetFloatArrayElements(inInterleavedStereo, nullptr);
    if (!inPtr) return env->NewFloatArray(0);

    auto rendered = engine->renderProcessedOffline(inPtr, len / 2);
    env->ReleaseFloatArrayElements(inInterleavedStereo, inPtr, JNI_ABORT);

    jfloatArray out = env->NewFloatArray(static_cast<jsize>(rendered.size()));
    if (out && !rendered.empty()) {
        env->SetFloatArrayRegion(out, 0, static_cast<jsize>(rendered.size()), rendered.data());
    }
    return out;
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeGetStatusMetrics(
    JNIEnv* env,
    jobject,
    jlong handle,
    jfloatArray outMetrics
) {
    auto* engine = fromHandle(handle);
    if (!engine || !outMetrics || env->GetArrayLength(outMetrics) < 8) return;
    float metrics[8] = {0.0f};
    engine->getStatusMetrics(metrics);
    env->SetFloatArrayRegion(outMetrics, 0, 8, metrics);
}

JNIEXPORT void JNICALL
Java_com_digitaldelay6_app_audio_NativeDelayEngine_nativeGetWaveform(
    JNIEnv* env,
    jobject,
    jlong handle,
    jfloatArray outSamples
) {
    auto* engine = fromHandle(handle);
    if (!engine || !outSamples) return;
    const jsize len = env->GetArrayLength(outSamples);
    if (len <= 0) return;

    float buffer[DelayAudioEngine::kWaveformSize] = {0.0f};
    const int32_t count = std::min(static_cast<int32_t>(len), DelayAudioEngine::kWaveformSize);
    engine->getWaveform(buffer, count);
    env->SetFloatArrayRegion(outSamples, 0, count, buffer);
}

} // extern "C"
