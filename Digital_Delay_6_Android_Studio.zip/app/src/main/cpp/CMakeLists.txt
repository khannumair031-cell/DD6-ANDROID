cmake_minimum_required(VERSION 3.22.1)

project("digitaldelay6" LANGUAGES CXX)

find_package(oboe REQUIRED CONFIG)

add_library(
        digitaldelay6
        SHARED
        jni_bridge.cpp
        DelayAudioEngine.cpp
        DelayDspProcessor.cpp
        BiquadFilter.cpp
)

target_include_directories(
        digitaldelay6
        PRIVATE
        ${CMAKE_CURRENT_SOURCE_DIR}
)

target_link_libraries(
        digitaldelay6
        oboe::oboe
        android
        log
)
