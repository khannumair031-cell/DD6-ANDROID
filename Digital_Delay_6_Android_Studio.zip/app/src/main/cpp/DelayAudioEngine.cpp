#include "DelayAudioEngine.h"
#include <android/log.h>
#include <algorithm>
#include <cmath>

#define LOG_TAG "DigitalDelay6Engine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace digitaldelay6 {

DelayAudioEngine::DelayAudioEngine()
    : scratchInL_(kMaxCallbackFrames, 0.0f),
      scratchInR_(kMaxCallbackFrames, 0.0f),
      scratchOutL_(kMaxCallbackFrames, 0.0f),
      scratchOutR_(kMaxCallbackFrames, 0.0f),
      inputCaptureScratch_(kMaxCallbackFrames * 2, 0.0f) {}

DelayAudioEngine::~DelayAudioEngine() {
    stop();
}

bool DelayAudioEngine::start() {
    closeStreams();
    if (!openOutputStream()) {
        LOGE("Failed to open Oboe output stream");
        return false;
    }

    if (inputEnabled_.load(std::memory_order_relaxed)) {
        openInputStream();
    }

    oboe::Result result = outputStream_->requestStart();
    if (result != oboe::Result::OK) {
        LOGE("Failed to start output stream: %s", oboe::convertToText(result));
        closeStreams();
        return false;
    }

    if (inputStream_) {
        oboe::Result inRes = inputStream_->requestStart();
        if (inRes != oboe::Result::OK) {
            LOGW("Input stream failed to start (%s); continuing output stream",
                 oboe::convertToText(inRes));
            inputStream_->close();
            inputStream_.reset();
        }
    }

    return true;
}

void DelayAudioEngine::stop() {
    closeStreams();
}

void DelayAudioEngine::closeStreams() {
    if (inputStream_) {
        inputStream_->stop();
        inputStream_->close();
        inputStream_.reset();
    }
    if (outputStream_) {
        outputStream_->stop();
        outputStream_->close();
        outputStream_.reset();
    }
}

bool DelayAudioEngine::openOutputStream() {
    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Stereo)
        ->setUsage(oboe::Usage::Media)
        ->setContentType(oboe::ContentType::Music)
        ->setDataCallback(this)
        ->setErrorCallback(this);

    oboe::Result result = builder.openStream(outputStream_);
    if (result != oboe::Result::OK || !outputStream_) {
        return false;
    }

    const float sr = static_cast<float>(outputStream_->getSampleRate());
    sampleRateHz_.store(sr, std::memory_order_relaxed);
    framesPerBurst_.store(
        static_cast<float>(outputStream_->getFramesPerBurst()),
        std::memory_order_relaxed
    );

    outputStream_->setBufferSizeInFrames(outputStream_->getFramesPerBurst() * 2);
    dspProcessor_.prepare(sr);
    return true;
}

bool DelayAudioEngine::openInputStream() {
    if (!outputStream_) return false;

    oboe::AudioStreamBuilder inBuilder;
    inBuilder.setDirection(oboe::Direction::Input)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Mono)
        ->setSampleRate(outputStream_->getSampleRate())
        ->setInputPreset(oboe::InputPreset::Unprocessed);

    oboe::Result res = inBuilder.openStream(inputStream_);
    if (res != oboe::Result::OK || !inputStream_) {
        inputStream_.reset();
        return false;
    }
    return true;
}

void DelayAudioEngine::setInputEnabled(bool enabled) noexcept {
    bool prev = inputEnabled_.exchange(enabled, std::memory_order_relaxed);
    if (prev != enabled && outputStream_) {
        if (enabled && !inputStream_) {
            if (openInputStream() && inputStream_) {
                inputStream_->requestStart();
            }
        } else if (!enabled && inputStream_) {
            inputStream_->stop();
            inputStream_->close();
            inputStream_.reset();
        }
    }
}

void DelayAudioEngine::clearHoldLoop() noexcept {
    pendingClearHold_.store(true, std::memory_order_release);
}

void DelayAudioEngine::triggerTestPluck(float frequencyHz) noexcept {
    pendingPluckFreq_.store(frequencyHz, std::memory_order_release);
}

void DelayAudioEngine::loadImportedAudio(const float* interleavedStereo, int32_t numFrames) {
    std::lock_guard<std::mutex> lock(importedMutex_);
    if (!interleavedStereo || numFrames <= 0) {
        importedLeft_.clear();
        importedRight_.clear();
        importedPlayIndex_.store(0, std::memory_order_relaxed);
        return;
    }
    importedLeft_.resize(static_cast<size_t>(numFrames));
    importedRight_.resize(static_cast<size_t>(numFrames));
    for (int32_t i = 0; i < numFrames; ++i) {
        importedLeft_[i] = interleavedStereo[i * 2];
        importedRight_[i] = interleavedStereo[i * 2 + 1];
    }
    importedPlayIndex_.store(0, std::memory_order_relaxed);
}

void DelayAudioEngine::setImportedPlayback(bool playing, bool looping) noexcept {
    importedLooping_.store(looping, std::memory_order_relaxed);
    importedPlaying_.store(playing, std::memory_order_relaxed);
}

void DelayAudioEngine::seekImportedNormalized(float position01) noexcept {
    std::lock_guard<std::mutex> lock(importedMutex_);
    if (importedLeft_.empty()) {
        importedPlayIndex_.store(0, std::memory_order_relaxed);
        return;
    }
    const float clamped = std::clamp(position01, 0.0f, 1.0f);
    const auto target = static_cast<int32_t>(clamped * static_cast<float>(importedLeft_.size() - 1));
    importedPlayIndex_.store(target, std::memory_order_relaxed);
}

void DelayAudioEngine::setRecording(bool recording) {
    if (recording) {
        std::lock_guard<std::mutex> lock(recordMutex_);
        recordedInterleaved_.clear();
        recordedInterleaved_.reserve(static_cast<size_t>(sampleRateHz_.load() * 2 * 30));
    }
    isRecording_.store(recording, std::memory_order_release);
}

std::vector<float> DelayAudioEngine::getRecordedStereoPcm() const {
    std::lock_guard<std::mutex> lock(recordMutex_);
    return recordedInterleaved_;
}

std::vector<float> DelayAudioEngine::renderProcessedOffline(
    const float* inInterleavedStereo,
    int32_t numFrames
) {
    if (!inInterleavedStereo || numFrames <= 0) {
        return {};
    }

    const float sr = sampleRateHz_.load(std::memory_order_relaxed);
    DelayDspProcessor offlineDsp;
    offlineDsp.prepare(sr);

    DelayParameters params;
    params.effectLevel = effectLevel_.load(std::memory_order_relaxed);
    params.feedback = feedback_.load(std::memory_order_relaxed);
    params.delayTimeMs = delayTimeMs_.load(std::memory_order_relaxed);
    params.mode = static_cast<Dd6Mode>(
        std::clamp(modeOrdinal_.load(std::memory_order_relaxed), 0, 6)
    );
    params.bypassed = false;
    params.pedalHeld = false;
    params.holdState = HoldState::Idle;

    const int32_t tailFrames = static_cast<int32_t>(sr * 1.5f);
    const int32_t totalFrames = numFrames + tailFrames;

    std::vector<float> inL(totalFrames, 0.0f);
    std::vector<float> inR(totalFrames, 0.0f);
    std::vector<float> outL(totalFrames, 0.0f);
    std::vector<float> outR(totalFrames, 0.0f);

    for (int32_t i = 0; i < numFrames; ++i) {
        inL[i] = inInterleavedStereo[i * 2];
        inR[i] = inInterleavedStereo[i * 2 + 1];
    }

    offlineDsp.processStereoBlock(inL.data(), inR.data(), outL.data(), outR.data(), totalFrames, params);

    std::vector<float> rendered(static_cast<size_t>(totalFrames) * 2);
    for (int32_t i = 0; i < totalFrames; ++i) {
        rendered[i * 2] = std::tanh(outL[i] * 0.95f);
        rendered[i * 2 + 1] = std::tanh(outR[i] * 0.95f);
    }
    return rendered;
}

oboe::DataCallbackResult DelayAudioEngine::onAudioReady(
    oboe::AudioStream* /*audioStream*/,
    void* audioData,
    int32_t numFrames
) {
    auto* outInterleaved = static_cast<float*>(audioData);
    const int32_t frames = std::min(numFrames, kMaxCallbackFrames);

    if (pendingClearHold_.exchange(false, std::memory_order_acquire)) {
        dspProcessor_.clearHoldLoop();
    }

    const float pluckFreq = pendingPluckFreq_.exchange(0.0f, std::memory_order_acquire);
    if (pluckFreq > 0.0f) {
        dspProcessor_.triggerPluck(pluckFreq);
    }

    std::fill_n(scratchInL_.begin(), frames, 0.0f);
    std::fill_n(scratchInR_.begin(), frames, 0.0f);

    if (inputStream_ && inputEnabled_.load(std::memory_order_relaxed)) {
        auto readResult = inputStream_->read(inputCaptureScratch_.data(), frames, 0);
        if (readResult && readResult.value() > 0) {
            const int32_t readFrames = std::min(readResult.value(), frames);
            for (int32_t i = 0; i < readFrames; ++i) {
                const float sample = inputCaptureScratch_[i];
                scratchInL_[i] += sample;
                scratchInR_[i] += sample;
            }
        }
    }

    if (importedPlaying_.load(std::memory_order_relaxed)) {
        std::unique_lock<std::mutex> lock(importedMutex_, std::try_to_lock);
        if (lock.owns_lock() && !importedLeft_.empty()) {
            const int32_t total = static_cast<int32_t>(importedLeft_.size());
            int32_t pos = importedPlayIndex_.load(std::memory_order_relaxed);
            const bool loop = importedLooping_.load(std::memory_order_relaxed);

            for (int32_t i = 0; i < frames; ++i) {
                if (pos >= total) {
                    if (loop) {
                        pos = 0;
                    } else {
                        importedPlaying_.store(false, std::memory_order_relaxed);
                        break;
                    }
                }
                scratchInL_[i] += importedLeft_[pos];
                scratchInR_[i] += importedRight_[pos];
                pos++;
            }
            importedPlayIndex_.store(pos, std::memory_order_relaxed);
        }
    }

    DelayParameters params;
    params.effectLevel = effectLevel_.load(std::memory_order_relaxed);
    params.feedback = feedback_.load(std::memory_order_relaxed);
    params.delayTimeMs = delayTimeMs_.load(std::memory_order_relaxed);
    params.mode = static_cast<Dd6Mode>(
        std::clamp(modeOrdinal_.load(std::memory_order_relaxed), 0, 6)
    );
    params.bypassed = bypassed_.load(std::memory_order_relaxed);
    params.pedalHeld = pedalHeld_.load(std::memory_order_relaxed);
    params.holdState = static_cast<HoldState>(
        std::clamp(holdStateOrdinal_.load(std::memory_order_relaxed), 0, 3)
    );

    dspProcessor_.processStereoBlock(
        scratchInL_.data(),
        scratchInR_.data(),
        scratchOutL_.data(),
        scratchOutR_.data(),
        frames,
        params
    );

    float sumInSq = 0.0f;
    float sumOutSq = 0.0f;
    float peakOut = 0.0f;
    int32_t waveIdx = waveformWritePos_.load(std::memory_order_relaxed);

    for (int32_t i = 0; i < frames; ++i) {
        const float limitedL = std::tanh(scratchOutL_[i] * 0.95f);
        const float limitedR = std::tanh(scratchOutR_[i] * 0.95f);

        outInterleaved[i * 2] = limitedL;
        outInterleaved[i * 2 + 1] = limitedR;

        const float inMono = 0.5f * (scratchInL_[i] + scratchInR_[i]);
        const float outMono = 0.5f * (limitedL + limitedR);

        sumInSq += inMono * inMono;
        sumOutSq += outMono * outMono;
        peakOut = std::max(peakOut, std::max(std::abs(limitedL), std::abs(limitedR)));

        if ((i & 7) == 0) {
            waveformRing_[waveIdx].store(outMono, std::memory_order_relaxed);
            waveIdx = (waveIdx + 1) & (kWaveformSize - 1);
        }
    }

    if (isRecording_.load(std::memory_order_acquire)) {
        std::unique_lock<std::mutex> recLock(recordMutex_, std::try_to_lock);
        if (recLock.owns_lock() && recordedInterleaved_.size() < 48000 * 2 * 180) {
            recordedInterleaved_.insert(
                recordedInterleaved_.end(),
                outInterleaved,
                outInterleaved + (frames * 2)
            );
        }
    }

    for (int32_t i = frames; i < numFrames; ++i) {
        outInterleaved[i * 2] = 0.0f;
        outInterleaved[i * 2 + 1] = 0.0f;
    }

    waveformWritePos_.store(waveIdx, std::memory_order_relaxed);
    const float invFrames = 1.0f / static_cast<float>(std::max(1, frames));
    inputRms_.store(std::sqrt(sumInSq * invFrames), std::memory_order_relaxed);
    outputRms_.store(std::sqrt(sumOutSq * invFrames), std::memory_order_relaxed);
    outputPeak_.store(peakOut, std::memory_order_relaxed);

    return oboe::DataCallbackResult::Continue;
}

void DelayAudioEngine::onErrorAfterClose(oboe::AudioStream* /*audioStream*/, oboe::Result error) {
    if (error == oboe::Result::ErrorDisconnected) {
        start();
    }
}

void DelayAudioEngine::getStatusMetrics(float* outEightFloats) const noexcept {
    outEightFloats[0] = inputRms_.load(std::memory_order_relaxed);
    outEightFloats[1] = outputRms_.load(std::memory_order_relaxed);
    outEightFloats[2] = outputPeak_.load(std::memory_order_relaxed);
    outEightFloats[3] = sampleRateHz_.load(std::memory_order_relaxed);
    outEightFloats[4] = framesPerBurst_.load(std::memory_order_relaxed);
    outEightFloats[5] = dspProcessor_.getHoldProgress();
    outEightFloats[6] = dspProcessor_.getHoldDurationSeconds();

    float importProgress = 0.0f;
    {
        std::unique_lock<std::mutex> lock(importedMutex_, std::try_to_lock);
        if (lock.owns_lock() && !importedLeft_.empty()) {
            importProgress = static_cast<float>(importedPlayIndex_.load(std::memory_order_relaxed)) /
                             static_cast<float>(importedLeft_.size());
        }
    }
    outEightFloats[7] = importProgress;
}

void DelayAudioEngine::getWaveform(float* outSamples, int32_t count) const noexcept {
    const int32_t n = std::min(count, kWaveformSize);
    const int32_t head = waveformWritePos_.load(std::memory_order_relaxed);
    for (int32_t i = 0; i < n; ++i) {
        const int32_t idx = (head - n + i + kWaveformSize) & (kWaveformSize - 1);
        outSamples[i] = waveformRing_[idx].load(std::memory_order_relaxed);
    }
}

} // namespace digitaldelay6
