# Keep JNI native bridge methods intact
-keep class com.digitaldelay6.app.audio.NativeDelayEngine {
    native <methods>;
}
-keepclasseswithmembernames class * {
    native <methods>;
}
